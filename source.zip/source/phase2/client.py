import requests
from colorama import Fore, init
import pyfiglet
import random

# Initialize colorama for colored text
init(autoreset=True)

def display_header():
    ascii_banner = pyfiglet.figlet_format("Tax Estimator")
    print(Fore.CYAN + ascii_banner)
    print(Fore.YELLOW + "Welcome to the Tax Estimation Console Application")
    print(Fore.YELLOW + "-" * 60)

def collect_user_data():
    try:
        print(Fore.GREEN + "\nPlease provide the following details:")
        tfn = input(Fore.CYAN + "Do you have a Tax File Number (TFN)? (y/n): ")

        if tfn.lower() == 'y':
            person_id = input(Fore.CYAN + "Enter Person ID: ")
            data = {'person_id': person_id}
            data['tfn'] = input(Fore.CYAN + "Enter your TFN: ")
            has_health_insurance = input(Fore.CYAN + "Do you have Private Health Insurance? (y/n): ")
            data['has_health_insurance'] = has_health_insurance.lower() == 'y'
        elif tfn.lower() == 'n':
            print(Fore.LIGHTRED_EX + "\nYou don't have a Tax File Number (TFN). You may want to register for one.")
            person_id = input(Fore.CYAN + "Enter Person ID: ")
            wages = []
            print(Fore.LIGHTGREEN_EX + "\nLet's enter your wage details.")
            while True:
                try:
                    gross_income = float(input(Fore.LIGHTCYAN_EX + "Enter gross income (enter -1 to stop): "))
                    if gross_income == -1:
                        break
                    net_income = float(input(Fore.LIGHTCYAN_EX + "Enter net income: "))
                    tax_withheld = float(input(Fore.LIGHTCYAN_EX + "Enter tax withheld for this income: "))
                    wages.append({'gross_income': gross_income, 'net_income': net_income, 'tax_withheld': tax_withheld})
                except ValueError:
                    print(Fore.RED + "Invalid input. Please enter a numeric value.")
            
            data = {
                'person_id': person_id,
                'wages': wages
            }
            has_health_insurance = input(Fore.CYAN + "Do you have Private Health Insurance? (y/n): ")
            data['has_health_insurance'] = has_health_insurance.lower() == 'y'

            save_details = input(Fore.CYAN + "Do you want to save your details and register for a TFN? (y/n): ")
            if save_details.lower() == 'y':
                # Generate a 6-digit TFN
                generated_tfn = random.randint(100000, 999999)
                data['tfn'] = generated_tfn
                data['register_new'] = True
                print(Fore.GREEN + f"\nYour new TFN is {generated_tfn}. Your details will be saved.")
            else:
                data['register_new'] = False
        else:
            print(Fore.RED + "Invalid input. Please answer with 'y' or 'n'.")
            return None
        return data
    except Exception as e:
        print(Fore.RED + f"An error occurred while collecting data: {e}")
        return None

def print_tax_result(result):
    print(Fore.YELLOW + "\n" + "=" * 40)
    print(Fore.LIGHTMAGENTA_EX + "Tax Estimation Results:")
    print(Fore.LIGHTCYAN_EX + f"Person ID: {result.get('person_id', 'N/A')}")
    print(Fore.LIGHTCYAN_EX + f"Taxable Income: {result.get('taxable_income') if result.get('taxable_income') is not None else 'N/A'}")
    print(Fore.LIGHTCYAN_EX + f"Tax Withheld: {result.get('tax_withheld') if result.get('tax_withheld') is not None else 'N/A'}")
    print(Fore.LIGHTCYAN_EX + f"Tax Due: {result.get('tax_due') if result.get('tax_due') is not None else 'N/A'}")
    print(Fore.LIGHTCYAN_EX + f"Medicare Levy: {result.get('medicare_levy') if result.get('medicare_levy') is not None else 'N/A'}")
    print(Fore.LIGHTCYAN_EX + f"Medicare Levy Surcharge: {result.get('medicare_surcharge') if result.get('medicare_surcharge') is not None else 'N/A'}")
    print(Fore.LIGHTCYAN_EX + f"Tax Refund/Payable: {result.get('tax_refund') if result.get('tax_refund') is not None else 'N/A'}")
    print(Fore.YELLOW + "=" * 40 + "\n")

def main():
    try:
        display_header()
        user_data = collect_user_data()
        
        if user_data is None:
            print(Fore.RED + "Error: Failed to collect user data.")
            input(Fore.CYAN + "\nPress Enter to exit...")
            return

        print(Fore.LIGHTBLUE_EX + "\nProcessing your request, please wait...")

        response = requests.post('http://localhost:5000/calculate_tax', json=user_data)
        response.raise_for_status()

        try:
            result = response.json()
            if 'error' in result:
                print(Fore.RED + f"Server error: {result['error']}")
            else:
                print_tax_result(result)
        except ValueError:
            print(Fore.RED + "Error: Received invalid JSON response from the server.")
        
    except requests.exceptions.RequestException as e:
        print(Fore.RED + f"An error occurred while making the request: {e}")
    except Exception as e:
        print(Fore.RED + f"An unexpected error occurred: {e}")
    finally:
        input(Fore.CYAN + "\nPress Enter to exit...")

if __name__ == '__main__':
    main()

