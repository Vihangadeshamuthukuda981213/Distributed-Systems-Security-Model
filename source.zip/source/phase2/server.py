from flask import Flask, request, jsonify
import mysql.connector

app = Flask(__name__)

def connect_to_database():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="pitre_db"
    )

def get_user_tax_data(person_id):
    """Fetch tax records for the given person_id from the database."""
    db = connect_to_database()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM payroll_records WHERE person_id = %s", (person_id,))
    result = cursor.fetchall()
    db.close()
    return result

def insert_new_user(person_id, tfn, wages, has_health_insurance):
    """Insert new user data into the payroll_records table."""
    db = connect_to_database()
    cursor = db.cursor()

    for wage in wages:
        gross_income = wage.get('gross_income')
        net_income = wage.get('net_income')
        tax_withheld = wage.get('tax_withheld')

        if gross_income is None or net_income is None or tax_withheld is None:
            continue

        cursor.execute("""
            INSERT INTO payroll_records (person_id, tfn, net_income, tax_withheld, gross_income, has_health_insurance)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (person_id, tfn, net_income, tax_withheld, gross_income, has_health_insurance))

    db.commit()
    db.close()

def calculate_tax(taxable_income):
    """Calculate tax based on taxable income."""
    taxable_income = float(taxable_income)
    if taxable_income <= 18200:
        return 0
    elif taxable_income <= 45000:
        return 0.19 * (taxable_income - 18200)
    elif taxable_income <= 120000:
        return 5092 + 0.325 * (taxable_income - 45000)
    elif taxable_income <= 180000:
        return 29467 + 0.37 * (taxable_income - 120000)
    else:
        return 51667 + 0.45 * (taxable_income - 180000)

@app.route('/calculate_tax', methods=['POST'])
def calculate_tax_estimate():
    """Calculate tax for registered users, newly registered users, and users without a TFN."""
    try:
        data = request.json

        # Case 1: Newly registered user
        if 'register_new' in data and data['register_new']:
            insert_new_user(
                data['person_id'],
                data['tfn'],
                data['wages'],
                data['has_health_insurance']
            )

            # Calculate tax based on the wage data provided by the new user
            wages = data['wages']
            taxable_income = sum(float(w['net_income']) for w in wages)
            tax_withheld = sum(float(w['tax_withheld']) for w in wages)
            tax_due = calculate_tax(taxable_income)

            # Calculate Medicare Levy (ML) at 2%
            ml = taxable_income * 0.02

            # Calculate Medicare Levy Surcharge (MLS) if no private health insurance
            mls = 0
            if taxable_income > 90000 and not data['has_health_insurance']:
                mls = taxable_income * 0.01

            # Calculate final tax refund or amount payable
            tax_refund = tax_withheld - (tax_due + ml + mls)

            return jsonify({
                'person_id': data['person_id'],
                'taxable_income': taxable_income,
                'tax_withheld': tax_withheld,
                'tax_due': tax_due,
                'medicare_levy': ml,
                'medicare_surcharge': mls,
                'tax_refund': tax_refund if tax_refund >= 0 else f"Tax payable: {abs(tax_refund)}"
            })

        # Case 2: Registered user with a TFN
        elif 'tfn' in data:
            person_id = data['person_id']
            tax_data = get_user_tax_data(person_id)
            if not tax_data:
                return jsonify({'error': 'No tax record found for this Person ID'}), 404

            # Use taxable_income and tax_withheld directly from the database
            taxable_income = sum(float(record['net_income']) for record in tax_data)
            tax_withheld = sum(float(record['tax_withheld']) for record in tax_data)
            has_health_insurance = any(record['has_health_insurance'] for record in tax_data)
            tax_due = calculate_tax(taxable_income)

            ml = taxable_income * 0.02

            mls = 0
            if taxable_income > 90000 and not has_health_insurance:
                mls = taxable_income * 0.01

            tax_refund = tax_withheld - (tax_due + ml + mls)

            return jsonify({
                'person_id': person_id,
                'taxable_income': taxable_income,
                'tax_withheld': tax_withheld,
                'tax_due': tax_due,
                'medicare_levy': ml,
                'medicare_surcharge': mls,
                'tax_refund': tax_refund if tax_refund >= 0 else f"Tax payable: {abs(tax_refund)}"
            })

        # Case 3: Registered user without a TFN, using person_id to fetch details
        elif 'person_id' in data:
            person_id = data['person_id']
            tax_data = get_user_tax_data(person_id)
            if not tax_data:
                return jsonify({'error': 'No tax record found for this Person ID'}), 404

            # Use taxable_income and tax_withheld directly from the database
            taxable_income = sum(float(record['net_income']) for record in tax_data)
            tax_withheld = sum(float(record['tax_withheld']) for record in tax_data)
            has_health_insurance = any(record['has_health_insurance'] for record in tax_data)
            tax_due = calculate_tax(taxable_income)

            ml = taxable_income * 0.02

            mls = 0
            if taxable_income > 90000 and not has_health_insurance:
                mls = taxable_income * 0.01

            tax_refund = tax_withheld - (tax_due + ml + mls)

            return jsonify({
                'person_id': person_id,
                'taxable_income': taxable_income,
                'tax_withheld': tax_withheld,
                'tax_due': tax_due,
                'medicare_levy': ml,
                'medicare_surcharge': mls,
                'tax_refund': tax_refund if tax_refund >= 0 else f"Tax payable: {abs(tax_refund)}"
            })
        else:
            return jsonify({'error': 'Invalid request'}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
