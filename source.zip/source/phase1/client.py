import requests
from colorama import Fore, init
import pyfiglet

# Initialize colorama for colored text
init(autoreset=True)

def display_header():
    ascii_banner = pyfiglet.figlet_format("Tax Estimator")
    print(Fore.CYAN + ascii_banner)
    print(Fore.YELLOW + "Welcome to the Tax Estimation Console Application")
    print(Fore.YELLOW + "-" * 60)

def collect_user_data():
    print(Fore.GREEN + "\nPlease provide the following details:")
    tfn = input(Fore.CYAN + "Do you have a Tax File Number (TFN)? (y/n): ")

    data = {}
    if tfn.lower() == 'y':
        data['tfn'] = input(Fore.CYAN + "Enter your TFN: ")
        data['person_id'] = input(Fore.CYAN + "Enter Person ID: ")
        wages = []

        print(Fore.LIGHTGREEN_EX + "\nLet's enter your wage details.")
        for i in range(1, 27):  # Limit to a maximum of 26 entries
            try:
                net_income = float(input(Fore.LIGHTCYAN_EX + f"Enter net income for period {i} (enter -1 to stop): "))
                if net_income == -1:
                    break
                tax_withheld = float(input(Fore.LIGHTCYAN_EX + "Enter tax withheld for this income: "))
                wages.append({'net_income': net_income, 'tax_withheld': tax_withheld})
            except ValueError:
                print(Fore.RED + "Invalid input. Please enter a numeric value.")

        data['wages'] = wages
        data['has_health_insurance'] = input(Fore.CYAN + "Do you have Private Health Insurance? (y/n): ").lower() == 'y'
        return data
    else:
        # Inform the user they need to register before proceeding
        print(Fore.RED + "\nYou don't have a Tax File Number (TFN). You need to register first before estimating your tax.")
        return None

def display_results(result):
    """Display the results received from the server."""
    if 'error' in result:
        print(Fore.RED + f"Error from server: {result['error']}")
        return

    print(Fore.LIGHTYELLOW_EX + "\nTax Estimation Results:")
    print(Fore.YELLOW + "-" * 50)
    print(Fore.CYAN + f"Annual Taxable Income: {result.get('annual_taxable_income', 'Error')}")
    print(Fore.CYAN + f"Total Tax Withheld: {result.get('total_tax_withheld', 'Error')}")
    print(Fore.CYAN + f"Basic Tax: {result.get('basic_tax', 'Error')}")
    print(Fore.CYAN + f"Medicare Levy: {result.get('medicare_levy', 'Error')}")
    print(Fore.CYAN + f"Medicare Levy Surcharge: {result.get('medicare_levy_surcharge', 'Error')}")
    print(Fore.CYAN + f"Total Tax Due: {result.get('tax_due', 'Error')}")
    print(Fore.CYAN + f"Tax Refund or Payable: {result.get('tax_refund_or_payable', 'Error')}")
    print(Fore.YELLOW + "-" * 50)

def main():
    display_header()
    user_data = collect_user_data()

    if user_data is None:
        print(Fore.YELLOW + "\nPlease register for a Tax File Number (TFN) to proceed.")
        input(Fore.CYAN + "\nPress Enter to exit...")
        return

    print(Fore.LIGHTBLUE_EX + "\nProcessing your request, please wait...")
    try:
        # Make a request to the server
        response = requests.post('http://localhost:5000/calculate_tax', json=user_data)
        response.raise_for_status()
        result = response.json()

        # Display results based on the server response
        display_results(result)
    except requests.RequestException as e:
        print(Fore.RED + f"An error occurred: {e}")
    
    # Wait for the user to press Enter before exiting
    input(Fore.CYAN + "\nPress Enter to exit...")

if __name__ == '__main__':
    main()
