from flask import Flask, request, jsonify

app = Flask(__name__)

# Function to calculate basic tax based on taxable income using the given tax brackets
def calculate_basic_tax(taxable_income):
    if taxable_income <= 18200:
        return 0
    elif taxable_income <= 45000:
        return 0.19 * (taxable_income - 18200)
    elif taxable_income <= 120000:
        return 5092 + 0.325 * (taxable_income - 45000)
    elif taxable_income <= 180000:
        return 29467 + 0.37 * (taxable_income - 120000)
    else:
        return 51667 + 0.45 * (taxable_income - 180000)

# Route for calculating tax estimates
@app.route('/calculate_tax', methods=['POST'])
def calculate_tax_estimate():
    try:
        data = request.json

        # Extract wages and tax withheld details from the data
        wages = data.get('wages', [])
        has_health_insurance = data.get('has_health_insurance', False)

        # Calculate total taxable income and total tax withheld
        taxable_income = sum(float(w['net_income']) for w in wages)
        total_tax_withheld = sum(float(w['tax_withheld']) for w in wages)

        # Calculate the basic tax based on taxable income
        basic_tax = calculate_basic_tax(taxable_income)

        # Calculate Medicare Levy (ML) at 2% of taxable income
        ml = taxable_income * 0.02

        # Calculate Medicare Levy Surcharge (MLS) if applicable
        mls = 0
        if taxable_income > 90000 and not has_health_insurance:
            if taxable_income <= 105000:
                mls = taxable_income * 0.01
            elif taxable_income <= 140000:
                mls = taxable_income * 0.0125
            else:
                mls = taxable_income * 0.015

        # Calculate final tax due
        tax_due = basic_tax + ml + mls

        # Calculate tax refund or payable
        tax_refund_or_payable = total_tax_withheld - tax_due

        # Log all the calculated values for debugging
        print(f"Calculated Tax Values:")
        print(f"Taxable Income: {taxable_income}")
        print(f"Total Tax Withheld: {total_tax_withheld}")
        print(f"Basic Tax: {basic_tax}")
        print(f"Medicare Levy: {ml}")
        print(f"Medicare Levy Surcharge: {mls}")
        print(f"Total Tax Due: {tax_due}")
        print(f"Tax Refund or Payable: {tax_refund_or_payable}")

        # Return the calculation results to the client
        return jsonify({
            'annual_taxable_income': round(taxable_income, 2),
            'total_tax_withheld': round(total_tax_withheld, 2),
            'basic_tax': round(basic_tax, 2),
            'medicare_levy': round(ml, 2),
            'medicare_levy_surcharge': round(mls, 2),
            'tax_due': round(tax_due, 2),
            'tax_refund_or_payable': round(tax_refund_or_payable, 2)
        })

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
